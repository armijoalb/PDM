package com.armijoruiz.alberto.mykotlinapp.other

class Config {
    companion object {
        var current_position : Int = 0
        var is_media_playing : Boolean = false
    }
}