package com.armijoruiz.alberto.mykotlinapp.interfaces

interface CustomMusicPlayerConnector {
    fun onPanelStateChanged(visibility:Boolean)
}