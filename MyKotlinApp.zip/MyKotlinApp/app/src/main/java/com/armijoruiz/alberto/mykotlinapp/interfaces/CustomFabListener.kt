package com.armijoruiz.alberto.mykotlinapp.interfaces

interface CustomFabListener {
    fun onFabListChanged()
}