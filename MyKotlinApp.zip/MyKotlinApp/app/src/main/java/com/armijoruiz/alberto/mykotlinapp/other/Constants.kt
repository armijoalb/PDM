package com.armijoruiz.alberto.mykotlinapp.other

const val PLAYSONG:String = "com.armijoruiz.alberto.mykotlinapp.action.PLAYSONG"
const val PLAYPAUSE:String = "com.armijoruiz.alberto.mykotlinapp.action.PLAYPAUSE"
const val NEXT:String = "com.armijoruiz.alberto.mykotlinapp.action.NEXT"
const val PREV:String = "com.armijoruiz.alberto.mykotlinapp.action.PREV"
const val SET_PROGRESS:String = "com.armijoruiz.alberto.mykotlinapp.action.SET_PROGRESS"
const val FINISH :String = "com.armijoruiz.alberto.mykotlinapp.action.FINISH"
const val ADD_FAB : String = "com.armijoruiz.alberto.mykotlinapp.action.ADD_FAB"
const val REM_FAB: String = "com.armijoruiz.alberto.mykotlinapp.action.REM_FAB"

