package com.armijoruiz.alberto.mykotlinapp.interfaces

import android.view.View

interface CustomOnItemClickListener {
    fun onItemClick(position:Int)
}